import com.amazonaws.auth.profile.ProfileCredentialsProvider
import org.apache.spark.sql.functions.{col, from_json}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.types.{DoubleType, LongType, StringType, StructType}

import java.util.HashMap
import scala.jdk.CollectionConverters.MapHasAsScala

object KafkaToOpenSearch {
  def main(args: Array[String]): Unit = {
    print("starting")
    val spark = SparkSession.builder()
      .appName("KafkaToOpenSearch")
      .getOrCreate()

    // Kafka topic and broker details
    val kafkaBootstrapServers = "test:9092"
    val kafkaTopic = "test-topic-hbase-kafka-updated"
//
    // OpenSearch details
    val openSearchIndex = "demo-os-kafka-hbase-index"
    val openSearchHost = "test"
//
//    // Configure OpenSearch client
    val credsProvider = new ProfileCredentialsProvider()
    val credentials = credsProvider.getCredentials
//
    val openSearchConfig = new HashMap[String, String]()
    openSearchConfig.put("es.nodes", openSearchHost)
    openSearchConfig.put("es.port", "443")
    openSearchConfig.put("es.net.http.auth.user", credentials.getAWSAccessKeyId)
    openSearchConfig.put("es.net.http.auth.pass", credentials.getAWSSecretKey)
    openSearchConfig.put("es.nodes.wan.only", "true")
    openSearchConfig.put("es.net.ssl", "true")
//
//    // Kafka consumer configuration
    val kafkaDF = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaBootstrapServers)
      .option("subscribe", kafkaTopic)
      .option("startingOffsets", "earliest")
      .load()

    val jsonDF = kafkaDF
      .selectExpr("CAST(value AS STRING)")
      .select(from_json(col("value"), schema).as("data"))
      .select("data.*")

    // Validate schema (use spark schema for your JSON structure)
    val validatedDF = jsonDF.filter(row => validateSchema(row))

    // Function to update the data in OpenSearch
    def updateOpenSearch(index: String, docId: String, data: Map[String, Any]): Unit = {
      // Convert Map[String, Any] to Row
      val row = Row.fromSeq(data.values.toSeq)
      val df = spark.createDataFrame(spark.sparkContext.parallelize(Seq(row)), schema)
      df.write
        .format("org.opensearch.spark.sql")
        .options(openSearchConfig.asScala.toMap)
        .mode("append")
        .save(index)
    }

    // Logic to update documents or index new ones
    validatedDF.writeStream.foreachBatch { (batchDF: DataFrame, batchId: Long) =>
      batchDF.collect().foreach { row =>
        val key = row.getAs[String]("key")
        val billingAddress = row.getAs[Map[String, String]]("billing_address")
        val shippingAddress = row.getAs[Map[String, String]]("shipping_address")
        val data = row.getAs[Map[String, Any]]("data")

        val docId = s"$key"
        updateOpenSearch(openSearchIndex, docId, Map(
          "billing_address" -> billingAddress,
          "shipping_address" -> shippingAddress,
          "data" -> data
        ))
      }
    }.start().awaitTermination()

    spark.stop()
  }

  // Define JSON schema for validation
  def schema: StructType = {
    new StructType()
      .add("key", StringType)
      .add("timestamp", LongType)
      .add("data", new StructType()
        .add("field1", DoubleType)
        .add("field2", DoubleType)
        .add("field3", DoubleType))
      .add("billing_address", new StructType()
        .add("street_address", StringType)
        .add("city", StringType)
        .add("state", StringType))
      .add("shipping_address", new StructType()
        .add("street_address", StringType)
        .add("city", StringType)
        .add("state", StringType))
  }

  // Function to validate schema
  def validateSchema(row: Row): Boolean = {
    // Implement validation logic here
    true
  }
}
