function test() {
    console.log("alert")
    console.log("alsdf");
}

test()