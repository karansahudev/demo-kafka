package in.capofila.userservice.services;

import in.capofila.userservice.entities.User;
import in.capofila.userservice.exception.ResourceNotFoundException;

public interface UserService {

    User save(User user);

    //get all user
    Iterable<User> getAllUsers();

    //get single user by id
    User getUserById(String userId);

    //delete user by id
    void deleteUserById(String userId);

    //update user by id
    User updateUserById(String userId, User user);

}
