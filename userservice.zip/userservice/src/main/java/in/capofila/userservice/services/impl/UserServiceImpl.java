package in.capofila.userservice.services.impl;

import in.capofila.userservice.entities.User;
import in.capofila.userservice.exception.ResourceNotFoundException;
import in.capofila.userservice.repositories.UserRepository;
import in.capofila.userservice.services.UserService;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;

    @Override
    public User save(User user) {
       String userId = UUID.randomUUID().toString();
       user.setUserId(userId);
        return userRepository.save(user);
    }

    @Override
    public Iterable<User> getAllUsers() {
       return userRepository.findAll();
    }

    @SneakyThrows
    @Override
    public User getUserById(String userId) {
        return userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User with Id: "+userId+" not found"));
    }

    @Override
    public void deleteUserById(String userId) {
        userRepository.deleteById(userId);
    }

    @Override
    public User updateUserById(String userId, User user) {
        return userRepository.saveAndFlush(user);
    }
}
