package in.capofila.userservice.controller;

import in.capofila.userservice.entities.User;
import in.capofila.userservice.services.KinesisService;
import in.capofila.userservice.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private KinesisService kinesisService;
    //create user
    @PostMapping("/register")
    public ResponseEntity<User> createUser(@RequestBody User user){
        kinesisService.sendEvent(user.getUserId(), user.toString());
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.save(user));
    }

    @GetMapping("/userId")
    public ResponseEntity<User> getSingleUser(@PathVariable String userId){
       User user = userService.getUserById(userId);
       return ResponseEntity.ok().body(user);
    }

    @GetMapping
    public ResponseEntity<Iterable<User>> getAllUsers(){
        Iterable<User> users = userService.getAllUsers();
        return  ResponseEntity.ok().body(users);
    }

}
