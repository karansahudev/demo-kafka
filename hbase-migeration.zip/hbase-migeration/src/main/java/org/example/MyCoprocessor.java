package org.example;

import org.apache.hadoop.hbase.CoprocessorEnvironment;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Durability;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.coprocessor.BaseRegionObserver;
import org.apache.hadoop.hbase.coprocessor.ObserverContext;
import org.apache.hadoop.hbase.coprocessor.RegionCoprocessorEnvironment;
import org.apache.hadoop.hbase.regionserver.wal.WALEdit;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.lambda.LambdaClient;
import software.amazon.awssdk.services.lambda.model.InvokeRequest;
import software.amazon.awssdk.services.lambda.model.InvokeResponse;

import java.io.IOException;


public class MyCoprocessor extends BaseRegionObserver {
    private LambdaClient lambdaClient;
    private static final Region REGION = Region.US_EAST_1; // Change to your AWS region

    @Override
    public void start(CoprocessorEnvironment env) throws IOException {
        super.start(env);
        lambdaClient = LambdaClient.builder()
                .region(REGION)
                .credentialsProvider(ProfileCredentialsProvider.create())
                .build();
    }

    @Override
    public void stop(CoprocessorEnvironment env) throws IOException {
        super.stop(env);
        if (lambdaClient != null) {
            lambdaClient.close();
        }
    }
    @Override
    public void prePut(ObserverContext<RegionCoprocessorEnvironment> e, Put put, WALEdit edit, Durability durability) throws IOException {
        super.prePut(e, put, edit, durability);
        lambdaClient = LambdaClient.builder()
                .region(REGION)
                .credentialsProvider(ProfileCredentialsProvider.create())
                .build();
    }

    @Override
    public void postPut(ObserverContext<RegionCoprocessorEnvironment> e, Put put, WALEdit edit, Durability durability) throws IOException {
        super.postPut(e, put, edit, durability);
        invokeLambda("prePut", put.toString(), "prePut");
    }

    @Override
    public void preDelete(ObserverContext<RegionCoprocessorEnvironment> e, Delete delete, WALEdit edit, Durability durability) throws IOException {
        super.preDelete(e, delete, edit, durability);
        invokeLambda("preDelete", edit.toString(), "preDelete");
    }

    @Override
    public void postDelete(ObserverContext<RegionCoprocessorEnvironment> e, Delete delete, WALEdit edit, Durability durability) throws IOException {
        super.postDelete(e, delete, edit, durability);
        invokeLambda("postDelete", edit.toString(), "postDelete");
    }


    private void invokeLambda(String action, String data, String functionName) {
        try {
            InvokeRequest invokeRequest = InvokeRequest.builder()
                    .functionName(functionName)
                    .payload(SdkBytes.fromUtf8String(data))
                    .build();

            InvokeResponse invokeResponse = lambdaClient.invoke(invokeRequest);
            System.out.println("Lambda " + action + " invoked, status: " + invokeResponse.statusCode());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
