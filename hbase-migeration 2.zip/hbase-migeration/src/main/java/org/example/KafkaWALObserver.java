package org.example;

import com.google.protobuf.Service;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.Coprocessor;
import org.apache.hadoop.hbase.CoprocessorEnvironment;
import org.apache.hadoop.hbase.coprocessor.WALCoprocessor;
import org.apache.hadoop.hbase.coprocessor.WALObserver;

import org.apache.hadoop.hbase.wal.WALEdit;
import org.apache.hadoop.hbase.wal.WALKey;

import org.apache.hadoop.hbase.coprocessor.ObserverContext;
import org.apache.hadoop.hbase.coprocessor.WALCoprocessorEnvironment;
import org.apache.hadoop.hbase.client.RegionInfo;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.example.service.KafkaService;

import java.io.IOException;
import java.util.Collections;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import static com.sun.tools.javac.util.Log.logKey;

public class KafkaWALObserver implements WALObserver, WALCoprocessor {

    private static KafkaProducer<String, String> producer;
    private static String topic = "hbase-wal-topic-2";

    @Override
    public void start(CoprocessorEnvironment env) throws IOException {
        System.out.println("KafkaWALObserver started");
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        producer = new KafkaProducer<>(props);
        KafkaService.createKafkaTopic(topic, props);
    }

    @Override
    public void stop(CoprocessorEnvironment env) throws IOException {
        if (producer != null) {
            producer.close();
        }
        System.out.println("KafkaWALObserver stopped");
    }

    @Override
    public Iterable<Service> getServices() {
        System.out.println("getServices invoked");
        return WALCoprocessor.super.getServices();
    }


//    public void preWALWrite(ObserverContext<? extends WALCoprocessorEnvironment> ctx, RegionInfo info, WALKey logKey, WALEdit logEdit) throws IOException {
//        WALObserver.super.preWALWrite(ctx, info, logKey, logEdit);
//        // Add logic if needed before the WAL write
//        String message = "Region: " + info.getRegionNameAsString() + ", Table: " + info.getTable().getNameAsString() + ", WALKey: " + logKey.toString();
//        producer.send(new ProducerRecord<>(topic, message));
//    }
//
//    public void postWALWrite(ObserverContext<? extends WALCoprocessorEnvironment> ctx, RegionInfo info, WALKey logKey, WALEdit logEdit) throws IOException {
//        WALObserver.super.postWALWrite(ctx, info, logKey, logEdit);
//        String message = "Region: " + info.getRegionNameAsString() + ", Table: " + info.getTable().getNameAsString() + ", WALKey: " + logKey.toString();
//        producer.send(new ProducerRecord<>(topic, message));
//    }

    @Override
    public Optional<WALObserver> getWALObserver() {
        System.out.println("KafkaWALObserver getWALObserver invoked");
        return Optional.empty();
    }

    @Override
    public void preWALRoll(ObserverContext<? extends WALCoprocessorEnvironment> ctx, Path oldPath, Path newPath) throws IOException {
        System.out.println("KafkaWALObserver preWALRoll invoked");
        WALObserver.super.preWALRoll(ctx, oldPath, newPath);
        String message = "Message: preWALRoll"+"Region: " + "test-region" + ", Table: " + " test table"+ ", WALKey: " + logKey.toString();
        producer.send(new ProducerRecord<>(topic, message));
        System.out.println("KafkaWALObserver preWALRoll finished");
    }

    @Override
    public void postWALRoll(ObserverContext<? extends WALCoprocessorEnvironment> ctx, Path oldPath, Path newPath) throws IOException {
        System.out.println("KafkaWALObserver postWALRoll invoked");
        WALObserver.super.postWALRoll(ctx, oldPath, newPath);
        String message = "Message: postWALRoll"+" Region: " + "test-region" + ", Table: " + " test table"+ ", WALKey: " + logKey.toString();
        producer.send(new ProducerRecord<>(topic, message));
        System.out.println("KafkaWALObserver postWALRoll finished");
    }


}
