package org.example.service;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.io.IOException;
import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class KafkaService {
    static Properties props;
    private static KafkaProducer<String, String> producer;
    {
        props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        producer = new KafkaProducer<>(props);
    }
    public static synchronized void produceMessage(String topicName, String message) throws IOException {
        try {
            producer = new KafkaProducer<>(props);
            System.out.println("Connected to Kafka");

            ProducerRecord<String, String> record = new ProducerRecord<>(topicName, message);

            // Send message with callback
            producer.send(record, (metadata, exception) -> {
                System.out.println(String.format("Starting producer to send message to {} with message {}", topicName, message));
                if (exception == null) {
                    System.out.println("Message sent successfully: " +
                            "Topic=" + metadata.topic() +
                            ", Partition=" + metadata.partition() +
                            ", Offset=" + metadata.offset());
                } else {
                    System.err.println("Failed to send message: " + exception.getMessage());
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            producer.flush();
            producer.close();
        }

    }

    public static synchronized void  createKafkaTopic(final String topicName, Properties properties) {
        // Create AdminClient
        try (AdminClient adminClient = AdminClient.create(properties)) {
            // Create a new topic
            int numPartitions = 1;
            short replicationFactor = 1;
            NewTopic newTopic = new NewTopic(topicName, numPartitions, replicationFactor);

            // Create topic
            adminClient.createTopics(Collections.singleton(newTopic)).all().get();

            System.out.println("Topic created successfully: " + topicName);
        } catch (InterruptedException | ExecutionException e) {
           e.printStackTrace();
        }finally {
            producer.flush();
            producer.close();
        }
    }
}
