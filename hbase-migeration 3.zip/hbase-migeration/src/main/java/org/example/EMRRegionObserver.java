package org.example;

import org.apache.hadoop.hbase.CoprocessorEnvironment;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.coprocessor.BaseRegionObserver;
import org.apache.hadoop.hbase.coprocessor.ObserverContext;
import org.apache.hadoop.hbase.coprocessor.RegionCoprocessorEnvironment;
import org.apache.hadoop.hbase.regionserver.wal.WALEdit;
import org.example.service.KafkaService;

import java.io.IOException;
public class EMRRegionObserver extends BaseRegionObserver {

    @Override
    public void start(CoprocessorEnvironment env){
        KafkaService service = new KafkaService();
        service.createKafkaTopic("test-topic");

    }
    @Override
    public void prePut(ObserverContext<RegionCoprocessorEnvironment> e, Put put, WALEdit edit, Durability durability) throws IOException {
            String topic = "test-topic-hbase-kafka-updated"; // Replace with your Kafka topic
        KafkaService service = new KafkaService();

        try {
            service.produceMessage("test-topic", "this is test mesage");
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void postPut(ObserverContext<RegionCoprocessorEnvironment> e, Put put, WALEdit edit, Durability durability) throws IOException {
        System.out.println("postPut");
    }

    @Override
    public void preDelete(ObserverContext<RegionCoprocessorEnvironment> e, Delete delete, WALEdit edit, Durability durability) throws IOException {
        System.out.println("preDelete");
    }

}
